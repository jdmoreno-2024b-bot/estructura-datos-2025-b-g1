import java.util.PriorityQueue;

// Clase que representa un cliente con prioridad
class Cliente implements Comparable<Cliente> {
    String nombre;
    int prioridad;

    // Constructor
    Cliente(String nombre, int prioridad) {
        this.nombre = nombre;
        this.prioridad = prioridad;
    }

    // Método que define el orden de prioridad (menor número = mayor prioridad)
    @Override
    public int compareTo(Cliente o) {
        return Integer.compare(this.prioridad, o.prioridad);
    }
}

public class SistemaAtencion {
    public static void main(String[] args) {
        // PriorityQueue organiza automáticamente según la prioridad definida
        PriorityQueue<Cliente> cola = new PriorityQueue<>();

        // Agregar clientes con distintas prioridades
        cola.add(new Cliente("Ana", 2));
        cola.add(new Cliente("Carlos", 1));
        cola.add(new Cliente("Beto", 3));

        // Atender clientes en orden de prioridad
        while (!cola.isEmpty()) {
            Cliente c = cola.poll(); // poll() obtiene y elimina el primero
            System.out.println("Atendiendo a: " + c.nombre);
        }
    }
}
