import java.util.Stack;

public class EditorTexto {
    // Pila para guardar los estados anteriores del texto
    private Stack<String> deshacer = new Stack<>();

    // Pila para guardar los estados que se pueden rehacer
    private Stack<String> rehacer = new Stack<>();

    // Variable que almacena el texto actual del editor
    private String textoActual = "";

    // Método para escribir nuevo texto
    public void escribir(String nuevoTexto) {
        deshacer.push(textoActual); // Guardar el estado anterior
        textoActual += nuevoTexto;  // Concatenar el nuevo texto
        rehacer.clear();            // Limpiar la pila de rehacer
    }

    // Método para deshacer la última acción
    public void deshacer() {
        if (!deshacer.isEmpty()) {
            rehacer.push(textoActual); // Guardar el estado actual en rehacer
            textoActual = deshacer.pop(); // Recuperar el último estado anterior
        }
    }

    // Método para rehacer la última acción deshecha
    public void rehacer() {
        if (!rehacer.isEmpty()) {
            deshacer.push(textoActual); // Guardar el estado actual
            textoActual = rehacer.pop(); // Recuperar el último estado rehacido
        }
    }

    // Obtener el texto actual del editor
    public String getTexto() {
        return textoActual;
    }

    public static void main(String[] args) {
        EditorTexto editor = new EditorTexto();
        editor.escribir("Hola ");
        editor.escribir("Mundo!");
        System.out.println(editor.getTexto()); // Muestra: Hola Mundo!
        editor.deshacer();
        System.out.println(editor.getTexto()); // Muestra: Hola
        editor.rehacer();
        System.out.println(editor.getTexto()); // Muestra: Hola Mundo!
    }
}
