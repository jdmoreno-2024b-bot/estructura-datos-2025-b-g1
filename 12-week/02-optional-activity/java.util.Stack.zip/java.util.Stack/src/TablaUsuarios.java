import java.util.HashMap;

public class TablaUsuarios {
    public static void main(String[] args) {
        // HashMap almacena pares clave-valor (ID, Nombre)
        HashMap<String, String> usuarios = new HashMap<>();

        // Insertar usuarios (clave única)
        usuarios.put("123", "Juan");
        usuarios.put("456", "María");
        usuarios.put("789", "Pedro");

        // Obtener un usuario por su clave
        System.out.println("Usuario 456: " + usuarios.get("456"));

        // Recorrer todos los usuarios
        for (String id : usuarios.keySet()) {
            System.out.println("ID: " + id + " -> " + usuarios.get(id));
        }
    }
}
