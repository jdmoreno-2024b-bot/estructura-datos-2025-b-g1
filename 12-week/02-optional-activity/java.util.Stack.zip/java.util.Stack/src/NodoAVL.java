// Nodo para árbol AVL
class NodoAVL {
    int valor, altura;
    NodoAVL izq, der;

    NodoAVL(int v) {
        valor = v;
        altura = 1; // Altura inicial del nodo
    }
}

// Aquí se implementan las rotaciones LL, RR, LR, RL para mantener el balance.
// Cada inserción verifica el "factor de balance" = altura izquierda - derecha.
// Si el factor > 1 o < -1, se realiza una rotación para equilibrar.
