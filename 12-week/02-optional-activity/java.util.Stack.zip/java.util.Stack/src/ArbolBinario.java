// Clase que representa un nodo del árbol binario
class Nodo {
    int valor;
    Nodo izq, der;

    Nodo(int valor) {
        this.valor = valor;
    }
}

public class ArbolBinario {
    Nodo raiz;

    // Recorrido en orden (izquierdo - raíz - derecho)
    void inOrden(Nodo nodo) {
        if (nodo != null) {
            inOrden(nodo.izq);
            System.out.print(nodo.valor + " ");
            inOrden(nodo.der);
        }
    }

    // Recorrido preorden (raíz - izquierdo - derecho)
    void preOrden(Nodo nodo) {
        if (nodo != null) {
            System.out.print(nodo.valor + " ");
            preOrden(nodo.izq);
            preOrden(nodo.der);
        }
    }

    // Recorrido postorden (izquierdo - derecho - raíz)
    void postOrden(Nodo nodo) {
        if (nodo != null) {
            postOrden(nodo.izq);
            postOrden(nodo.der);
            System.out.print(nodo.valor + " ");
        }
    }

    public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();

        // Crear estructura del árbol manualmente
        arbol.raiz = new Nodo(1);
        arbol.raiz.izq = new Nodo(2);
        arbol.raiz.der = new Nodo(3);
        arbol.raiz.izq.izq = new Nodo(4);
        arbol.raiz.izq.der = new Nodo(5);

        // Ejecutar recorridos
        System.out.print("InOrden: ");
        arbol.inOrden(arbol.raiz);
        System.out.println();

        System.out.print("PreOrden: ");
        arbol.preOrden(arbol.raiz);
        System.out.println();

        System.out.print("PostOrden: ");
        arbol.postOrden(arbol.raiz);
    }
}
